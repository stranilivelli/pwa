//Install event.........
self.addEventListener('install', evt =>{
    console.log('Service worker installato');
});
//activate event
self.addEventListener('activate', evt =>{
    console.log('Service worker attivato');
});
//fetch event
self.addEventListener('fetch', evt =>{
    console.log('evento fetch');
});
