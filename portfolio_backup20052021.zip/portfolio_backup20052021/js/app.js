//Collego il service Worker e controllo se è registrato
if('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js')
    .then(reg => console.log('il service worker è registrato'))
    .catch(err => console.log('il service worker NON è registrato'));
}
