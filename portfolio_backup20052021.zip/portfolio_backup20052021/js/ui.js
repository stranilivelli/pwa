//Apertura del pannello in JavaScript con evento click
const elementClicked = document.querySelector('.site-nav__hamburger');
const elementOpen = document.querySelector('.site-nav__menu');
const body = document.querySelector('body');
elementClicked.addEventListener('click', (e) => {
  elementOpen.classList.toggle('site-nav__menu--open');
   event.stopPropagation();
});
body.addEventListener('click', (e) => {
  elementOpen.classList.remove('site-nav__menu--open');
});
