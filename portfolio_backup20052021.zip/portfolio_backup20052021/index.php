<?
Header( "HTTP/1.1 301 Moved Permanently" );
Header( "Location: https://spaone.isialab.it/portfolio/index.html" );
?>
